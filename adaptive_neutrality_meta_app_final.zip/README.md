# Adaptive Neutrality Meta-Responder (OpenRouter Version)

This app sends your prompt to GPT-4, Claude 3 Sonnet, and Gemini Pro via OpenRouter.ai and analyzes their responses for neutrality.

## How to Use

### Step 1: Upload to GitHub
1. Go to https://github.com/new
2. Create a new repository (name it anything you want)
3. On your computer, unzip this folder.
4. Drag and drop the unzipped files into the new GitHub repo.
5. Commit the files.

### Step 2: Deploy to Streamlit
1. Go to https://streamlit.io/cloud
2. Click "New App"
3. Choose your GitHub repo
4. Set `streamlit_app_openrouter.py` as the main file
5. Click Deploy

### Step 3: Use It
- Paste your OpenRouter API key (from https://openrouter.ai/keys)
- Enter a prompt
- Choose AI personality and neutrality level
- Run and analyze responses from GPT-4, Claude, and Gemini
