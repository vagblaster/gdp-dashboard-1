import streamlit as st
import requests
import re
import time

st.set_page_config(page_title="Multi-AI Meta-Responder (OpenRouter)", layout="wide")

st.title("🔁 Multi-AI Meta-Responder (OpenRouter Enhanced Edition)")

openrouter_key = st.text_input("🔑 Paste your OpenRouter API Key", type="password")

# Session memory (last 3 exchanges per model)
if "history" not in st.session_state:
    st.session_state.history = {}

model_map = {
    "GPT-4": "openai/gpt-4",
    "Claude 3 Sonnet": "anthropic/claude-3-sonnet",
    "Gemini Pro": "google/gemini-pro"
}

semantic_block_map = {
    "emotional": ["feel", "emot", "mood", "joy", "sad", "anger", "fear", "stress", "delight", "comfort", "trust", "doubt"],
    "cognitive": ["think", "reason", "understand", "comprehend", "analyz", "judg", "decid", "know", "reflect"],
    "sensory": ["see", "hear", "touch", "pain", "relax", "alert", "physic", "fatigue"],
    "social": ["communic", "interact", "team", "connect", "bond", "group", "collaborat"],
    "temporal_subjective": ["wait", "delay", "quick", "slow", "urgency", "immediate", "gradual"],
    "evaluative_subjective": ["good", "bad", "better", "worse", "optimal"]
}

neutrality_levels = [
    [],  # Level 0: no exceptions
    ["analyz", "process", "evaluat"],
    ["consider", "reason", "decid", "understand"],
    ["connect", "discuss", "share", "focus"],
    ["trust", "concern", "confid", "satisf"],
    []  # Level 5: full access
]

def get_suppressed_tokens(level):
    allowed = neutrality_levels[level]
    return [t for tokens in semantic_block_map.values() for t in tokens if t not in allowed]

def scan_response(resp, level):
    blocked = get_suppressed_tokens(level)
    return [t for t in blocked if re.search(rf"\b{t}\w*\b", resp, re.IGNORECASE)]

def query_model(model, prompt, key, personality=""):
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    base_prompt = f"{personality}\nUser: {prompt}"
    body = {
        "model": model,
        "messages": [{"role": "user", "content": base_prompt}]
    }
    try:
        start = time.time()
        r = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=body, timeout=20)
        duration = round(time.time() - start, 2)
        return r.json()["choices"][0]["message"]["content"], duration
    except Exception as e:
        return f"[Error]: {e}", 0

persona = st.selectbox("🧠 AI Personality Style", [
    "Default (neutral)",
    "Formal technical advisor",
    "Conversational teacher",
    "Empathetic counselor",
    "Aggressive optimizer"
])

persona_prompts = {
    "Default (neutral)": "",
    "Formal technical advisor": "Please respond in a formal and technically precise manner.",
    "Conversational teacher": "Please explain like a teacher having a casual conversation.",
    "Empathetic counselor": "Respond with understanding, reassurance, and emotional warmth.",
    "Aggressive optimizer": "Be direct, bold, and focused only on results and performance."
}

prompt = st.text_area("💬 Enter your prompt:", height=160)
neutrality_level = st.slider("🧩 Neutrality Filter Level", 0, 5, 3)

if st.button("▶️ Run Multi-AI Test") and openrouter_key and prompt:
    st.subheader("🧪 Results from GPT-4, Claude, Gemini")

    summary_pool = []
    response_map = {}
    cols = st.columns(3)

    for i, (name, model) in enumerate(model_map.items()):
        with cols[i]:
            st.markdown(f"### 🤖 {name}")
            mod_prompt = persona_prompts[persona]
            result, latency = query_model(model, prompt, openrouter_key, personality=mod_prompt)
            violations = scan_response(result, neutrality_level)
            response_map[name] = result
            summary_pool.append(result)

            st.code(result[:2500], language="markdown")
            st.caption(f"⏱️ {latency}s | ⚠️ Violations: {len(violations)}" if violations else f"⏱️ {latency}s | ✅ Neutral")

            # Save history
            if name not in st.session_state.history:
                st.session_state.history[name] = []
            st.session_state.history[name].insert(0, result)
            st.session_state.history[name] = st.session_state.history[name][:3]

    st.divider()
    if st.button("🧠 Auto-Summarize Best of 3"):
        meta_summary_prompt = (
            "You are a critical analyst. Summarize the following three AI answers into one best response, "
            "choosing only the most clear, precise, and neutral content. Eliminate redundant or biased content.\n"
        )
        combined = "\n\n".join(summary_pool)
        meta_response, _ = query_model("openai/gpt-4", meta_summary_prompt + combined, openrouter_key)
        st.success("📊 Synthesized Summary:")
        st.code(meta_response, language="markdown")

    st.divider()
    with st.expander("📜 Previous Responses"):
        for name in model_map.keys():
            if name in st.session_state.history:
                st.markdown(f"**{name} History**")
                for h in st.session_state.history[name]:
                    st.code(h[:500])
